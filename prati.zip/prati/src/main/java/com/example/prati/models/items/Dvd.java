package com.example.prati.models.items;

public class Dvd extends ItemBiblioteca {
    public Dvd(String codigo, String titulo) {
        super(codigo, titulo);
    }

    @Override
    public int getPrazoDias() {
        return 10;
    }

    @Override
    public double getValorMultaDiaria() {
        return 2.50;
    }
}