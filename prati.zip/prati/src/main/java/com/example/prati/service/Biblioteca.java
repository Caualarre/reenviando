package com.example.prati.service;

import com.example.prati.models.items.ItemBiblioteca;
import com.example.prati.models.usuario.Usuario;

public class Biblioteca {
    private ItemBiblioteca[] acervo;
    private int totalItens;

    public Biblioteca(int capacidadeAcervo) {
        this.acervo = new ItemBiblioteca[capacidadeAcervo];
        this.totalItens = 0;
    }

    public void adicionarItem(ItemBiblioteca item) {
        if (totalItens < acervo.length) {
            acervo[totalItens++] = item;
        } else {
            System.out.println("Capacidade máxima do acervo atingida.");
        }
    }

    public boolean emprestar(ItemBiblioteca item, Usuario usuario) {
        if (item == null || usuario == null) return false;

        if (!item.isDisponivel()) {
            System.out.printf("Falha: O item '%s' já está emprestado.%n", item.getTitulo());
            return false;
        }

        if (!usuario.podeEmprestar()) {
            System.out.printf("Falha: %s atingiu o limite de %d itens emprestados.%n",
                    usuario.getNome(), usuario.getLimiteItens());
            return false;
        }

        item.marcarEmprestado();
        usuario.registrarEmprestimo();
        System.out.printf("Sucesso: '%s' emprestado para %s por %d dias.%n",
                item.getTitulo(), usuario.getNome(), item.getPrazoDias());
        return true;
    }

    public boolean devolver(ItemBiblioteca item, Usuario usuario) {
        if (item == null || usuario == null) return false;

        if (item.isDisponivel()) {
            System.out.printf("Falha: O item '%s' já consta como disponível.%n", item.getTitulo());
            return false;
        }

        item.marcarDevolvido();
        usuario.registrarDevolucao();
        System.out.printf("Sucesso: '%s' devolvido por %s.%n", item.getTitulo(), usuario.getNome());
        return true;
    }

    public void listarAcervo() {
        System.out.println("\n--- Acervo da Biblioteca ---");
        for (int i = 0; i < totalItens; i++) {
            System.out.println(acervo[i]);
        }
        System.out.println("----------------------------\n");
    }
}