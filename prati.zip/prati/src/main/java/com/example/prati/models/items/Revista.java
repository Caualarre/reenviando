package com.example.prati.models.items;

public class Revista extends ItemBiblioteca {
    public Revista(String codigo, String titulo) {
        super(codigo, titulo);
    }

    @Override
    public int getPrazoDias() {
        return 7;
    }

    @Override
    public double getValorMultaDiaria() {
        return 1.00;
    }
}