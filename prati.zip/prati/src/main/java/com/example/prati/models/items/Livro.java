package com.example.prati.models.items;

public class Livro extends ItemBiblioteca {
    public Livro(String codigo, String titulo) {
        super(codigo, titulo);
    }

    @Override
    public int getPrazoDias() {
        return 14;
    }

    @Override
    public double getValorMultaDiaria() {
        return 0.50;
    }
}