package com.example.prati;

import com.example.prati.models.items.Dvd;
import com.example.prati.models.items.ItemBiblioteca;
import com.example.prati.models.items.Livro;
import com.example.prati.models.items.Revista;
import com.example.prati.models.usuario.Aluno;
import com.example.prati.models.usuario.Professor;
import com.example.prati.models.usuario.Usuario;
import com.example.prati.service.Biblioteca;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PratiApplication {

        public static void main(String[] args) {
            Biblioteca biblio = new Biblioteca(15);

            // 1. Cadastro de itens no acervo (Livros e Revistas)
            ItemBiblioteca l1 = new Livro("HQ001", "Batman: O Cavaleiro das Trevas");
            ItemBiblioteca l2 = new Livro("MAN001", "Berserk - Edição de Luxo Vol. 1");
            ItemBiblioteca l3 = new Livro("MAN002", "One Piece - 3 em 1 Vol. 1");
            ItemBiblioteca l4 = new Livro("MHW001", "Solo Leveling Vol. 1");
            ItemBiblioteca l5 = new Livro("HQ002", "Watchmen - Edição Definitiva");
            ItemBiblioteca l6 = new Livro("MHA001", "Mo Dao Zu Shi (Grandmaster of Demonic Cultivation)");
            ItemBiblioteca l7 = new Livro("MAN003", "Chainsaw Man Vol. 1");

            ItemBiblioteca r1 = new Revista("REV001", "Shonen Jump Semanal");
            ItemBiblioteca r2 = new Revista("GIB001", "Turma da Mônica Jovem");

            ItemBiblioteca dvd1 = new Dvd("D001", "Pokémon 2000");

            biblio.adicionarItem(l1);
            biblio.adicionarItem(l2);
            biblio.adicionarItem(l3);
            biblio.adicionarItem(l4);
            biblio.adicionarItem(l5);
            biblio.adicionarItem(l6);
            biblio.adicionarItem(l7);
            biblio.adicionarItem(r1);
            biblio.adicionarItem(r2);
            biblio.adicionarItem(dvd1);

            // 2. Instanciação dos usuários
            Usuario aluno = new Aluno("Carlos Silva");
            Usuario prof = new Professor("Dra. Helena Vasconcelos");

            System.out.println("Listar Acervo antes");
            biblio.listarAcervo();

            System.out.println("Aluno teste");
            // 3 Empréstimos bem-sucedidos
            biblio.emprestar(l1, aluno);
            biblio.emprestar(l2, aluno);
            biblio.emprestar(r1, aluno);

            System.out.println("\n aluno passa limite permitido");
            biblio.emprestar(l3, aluno);

            System.out.println("\n tentar pegar item já emprestado");
            biblio.emprestar(l1, prof);

            System.out.println("\n teste devolução");
            biblio.devolver(l1, aluno);

            System.out.println("\n devolver item que já está disponível");
            biblio.devolver(l1, aluno);

            System.out.println("\n aluno pegando livro depois de devolver e ter espaço");
            biblio.emprestar(l3, aluno);

            System.out.println("\n professor escolhendo 5 items");

            biblio.emprestar(l1, prof);
            biblio.emprestar(l4, prof);
            biblio.emprestar(l5, prof);
            biblio.emprestar(l6, prof);
            biblio.emprestar(r2, prof);


            System.out.println("\n Professor estoura limite e tenta");
            biblio.emprestar(l7, prof);

            System.out.println("\n Listagem após operações vendo as alterações ocorridas depois de aberto a biblioteca");
            biblio.listarAcervo();
        }


}
