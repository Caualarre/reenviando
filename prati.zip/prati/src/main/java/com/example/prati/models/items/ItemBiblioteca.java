package com.example.prati.models.items;

public abstract class ItemBiblioteca {
    private String codigo;
    private String titulo;
    private boolean disponivel;

    public ItemBiblioteca(String codigo, String titulo) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.disponivel = true;
    }

    public abstract int getPrazoDias();
    public abstract double getValorMultaDiaria();

    public String getCodigo() {
        return codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    // A disponibilidade muda apenas via emprestar/devolver
    public void marcarEmprestado() {
        this.disponivel = false;
    }

    public void marcarDevolvido() {
        this.disponivel = true;
    }

    @Override
    public String toString() {
        return String.format("[%s] %s | Disponível: %s | Prazo: %d dias | Multa: R$ %.2f/dia",
                codigo, titulo, (disponivel ? "Sim" : "Não"), getPrazoDias(), getValorMultaDiaria());
    }
}